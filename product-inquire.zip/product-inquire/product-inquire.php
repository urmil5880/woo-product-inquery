<?php
/*
Plugin Name: Product inquire
Version: 1.0
Author: Name
Description: This pluging provide to product inquire
*/


function product_inquire_scripts() {

  wp_register_style( 'product-inquire-style', plugins_url('css/product-inquire.css', __FILE__) );
wp_enqueue_style( 'product-inquire-style' );
}
add_action( 'wp_enqueue_scripts', 'product_inquire_scripts' );


	/* Creating Menus */
	function product_inquire_Menu()
	{

		/* Adding menus */
		add_menu_page(__('Inquire List'),'Inquire List', 8,'proinq/inquirelist.php', 'inquire_list', "", 26);

		/* Adding Sub menus */
		//add_submenu_page('brplug/brandplg.php', 'Add Brand', 'Add Brand', 8, 'brand_add', 'brand_add');


	}
add_action('admin_menu', 'product_inquire_Menu');


function inquire_list(){
	include "product-inquire-list.php";
}


function del_inquire_record() {
	
	global $wpdb;
	$tablename = $wpdb->prefix.'product_inquire';
	$sql = "DELETE FROM $tablename WHERE id = ".$_REQUEST['del_id'];
	$wpdb->query($sql);
	die();
}
add_action('wp_ajax_del_inquire_record', 'del_inquire_record');
add_action('wp_ajax_nopriv_del_inquire_record', 'del_inquire_record');


//Shortcode to display form on product detaile page.
function form_product_inquire(){
?>
<form name="product_inquire_form" id="product_inquire_form" method="post">
<div class="row">

<div id="noti_product_inquire" class="col-md-12 alert"></div>

                        
                        <div class="col-md-5">
                            <div class="form-field">
                                <input type="text" placeholder="Name" class="form-control isrequired" name="inq_user_name" id="inq_user_name" />
                            </div>
                            <div class="form-field">
                                <input type="text" placeholder="E-Mail" class="form-control isrequired" name="inq_user_email" id="inq_user_email" />
                            </div>
                            <div class="form-field">
                                <input type="text" placeholder="Zip Code" class="form-control isrequired" name="inq_user_zip" id="inq_user_zip" />
                            </div>
                        </div>
                        <div class="col-md-7">
                            <div class="form-field">
                                <textarea placeholder="Message" class="form-control isrequired" name="inq_user_messgae" id="inq_user_message"></textarea>
                            </div>
                            <div class="form-action tar tac-xs tac-sm">
									<div id="inq_loding"><i class="fa fa-spinner fa-spin fa-2x fa-fw"></i></div>					
	                                <button class="btn ovalbtn btn_send_product_inquire">SEND</button>
									<input type="hidden" name="action" value="send_product_inquire">
									<input type="hidden" name="inq_product_id" value="<?php echo get_the_id(); ?>">
                            </div>
                        </div>
                    
                    </div>	
</form>
<script>
jQuery(document).ready(function($) {
		jQuery( ".btn_send_product_inquire" ).click(function() {

		jQuery("#noti_product_inquire.alert").hide(); 	
	
		//on focus
		jQuery("#product_inquire_form .isrequired, #product_inquire_form .isrequired").focus(function(){
			jQuery(this).removeClass('error');
		});
				//on blur
		jQuery("#product_inquire_form .isrequired, #product_inquire_form .isrequired").blur(function()
		{
			if(jQuery(this).val().trim() == '')
			{
				jQuery(this).addClass('error');
			} else {
				jQuery(this).removeClass('error');
			}
		});	
		
		if(jQuery("#inq_user_name").val().trim() == '' || jQuery("#inq_user_email").val().trim() == '' || jQuery("#inq_user_zip").val().trim() == '' || jQuery("#inq_user_message").val().trim() == '' )
		{
				jQuery("#noti_product_inquire.alert").show();
				jQuery("#noti_product_inquire.alert").addClass("alert-danger");
				jQuery("#noti_product_inquire.alert").html("Please enter required field"); 
			
				
			jQuery("#product_inquire_form .isrequired" ).each(function() {	
					filedValue = jQuery(this).val().trim();
					if(filedValue == '')
					{
						jQuery(this).addClass('error');
					} else {
						jQuery(this).removeClass('error');
					}
			});
		
		} else if (!ValidateEmail(jQuery("#inq_user_email").val())) {
			
				jQuery("#noti_product_inquire.alert").show();
				jQuery("#noti_product_inquire.alert").addClass("alert-danger");
				jQuery("#noti_product_inquire.alert").html("Please enter valid email address");   
				
		} else {

		var formData = jQuery("#product_inquire_form").serialize();
		jQuery("#inq_loding").show();
		
		jQuery.ajax({
        type:"POST",
				url: '<?php echo admin_url('admin-ajax.php'); ?>',
				 data: 		formData,
				 dataType: 'JSON',
                 success:function(data) {
        		jQuery("#inq_loding").hide();
        		if(data.status == 'success'){
        			jQuery("#noti_product_inquire.alert").show();
        			jQuery("#noti_product_inquire.alert").addClass("alert-success");
        			jQuery("#noti_product_inquire.alert").html(data.message);
        			window.location = "<?php echo get_permalink( get_page_by_path( 'thank-you' ) ); ?>";
            	//console.log(data);
            } else if(data.status == 'error'){
				   jQuery("#noti_product_inquire.alert").show();
        			jQuery("#noti_product_inquire.alert").addClass("alert-danger");
        			jQuery("#noti_product_inquire.alert").html(data.message);        
            }
        },
        error: function(errorThrown){
            console.log(errorThrown);
        }
    	});  
    	} 
			return false;
		});
	});
	
	function ValidateEmail(email) {
        var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
        return expr.test(email);
    };
</script>
<?php
}
add_shortcode('short_form_product_inquire', 'form_product_inquire');

function send_product_inquire() {

	$response_array = array();
	$productname = get_the_title($_POST['inq_product_id']);
	$producturl = get_the_permalink($_POST['inq_product_id']);
	
	$admin_email = get_option( 'admin_email' );
	//$admin_email = 'gequaldev@yahoo.co.in';
				
				$sender_email = sanitize_text_field($_POST['inq_user_email']);
				$sender_name = sanitize_text_field($_POST['inq_user_name']);
				$sender_zip = sanitize_text_field($_POST['inq_user_zip']);
				$inq_user_messgae = sanitize_text_field($_POST['inq_user_messgae']);
			
			$required = false;

			if ( empty( $sender_email ) ) {
				$required = true;
				$error = 'Please enter required field.';
			}else if(!filter_var($sender_email, FILTER_VALIDATE_EMAIL)){
				$required = true;
				$error = 'Please enter valid email address';
			}

			if ( empty( $sender_name ) ) {
				$required = true;
				$error = 'Please enter required field.';
			}

			if ( empty( $sender_zip ) ) {
				$required = true;
				$error = 'Please enter required field.';
			}

			if ( empty( $inq_user_messgae ) ) {
				$required = true;
				$error = 'Please enter required field.';
			}



			if($required == false){	
				$subject = "Product Inquire";
				
				$headers = "From: " . strip_tags($sender_email) . "\r\n";
				$headers .= "Reply-To: ". strip_tags($sender_email) . "\r\n";
				$headers .= "MIME-Version: 1.0\r\n";
				$headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
				
				
				$message = '<html><body>';
				
				$message .= "<strong>Name: </strong>".$sender_name;
				$message .= "<br>";
				$message .= "<strong>Email: </strong>".'<a href="mailto:'.$sender_email.'">'.$sender_email.'</a>';
				$message .= "<br>";
				$message .= "<strong>Zip Code : </strong>".$sender_zip;
				$message .= "<br>";
				$message .= "<strong>Message : </strong>".$inq_user_messgae;
				$message .= "<br>";
				$message .= "<strong>Product Name : </strong>".$productname;
				$message .= "<br>";				
				$message .= "<strong>Product Url : </strong><a href=".$producturl.">".$producturl."</a>";
				$message .= "<br>";
				$message .= "</body></html>";				
				
				$mailsent = wp_mail($admin_email,$subject,$message,$headers); 
				if($mailsent == true) {
						$response_array = array( 'status' => 'success', 'message' => 'your inquiry has been sent successfully');
						$_SESSION['product_inquire_user_email'] = $sender_email;			
				} else {
						$response_array = array( 'status' => 'error', 'message' => 'your inquiry not sent contact to administrator');	
				}
				
				global $wpdb;
				$tablename = $wpdb->prefix.'product_inquire';
					 
				$sql = "INSERT INTO $tablename (user_name, user_email, user_message, product_id, product_name, add_date) 
				VALUES ('".$_POST['inq_user_name']."','".$_POST['inq_user_email']."','".$_POST['inq_user_messgae']."','".$_POST['inq_product_id']."','".$productname."','".get_current_date_time()."')";	 
 				$wpdb->query($sql);

 			}
 			else{
 				$response_array = array( 'status' => 'error', 'message' => $error );
 			}

echo json_encode($response_array);				
die();
}
add_action('wp_ajax_send_product_inquire', 'send_product_inquire');
add_action('wp_ajax_nopriv_send_product_inquire', 'send_product_inquire');
?>
