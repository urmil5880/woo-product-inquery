<div class="wrap">
    <h2>Inquire List</h2>
	 <table class="wp-list-table widefat fixed " id="inquireList">
		<thead>
			<tr>
				<th>ID</th>
				<th>Name</th>
				<th>Email</th>
				<th>Message</th>
				<th>Product Name</th>
				<th>Date</th>
				<th>Action</th>
            </tr>
		</thead>
		<tbody>
<?php

	global $wpdb;	
	$tablename = $wpdb->prefix.'product_inquire';
	$result = $wpdb->get_results("select * from ".$tablename." ORDER BY id DESC");
	
	
		if ($result)
		{

		?>
				<script type="text/javascript">
				/* <![CDATA[ */
				jQuery(document).ready(function(){
					jQuery('#inquireList').dataTable();
				});
				/* ]]> */

				</script>

<?php

			foreach($result  as $results )
			{
								
				$id        = $results->id;
				$user_name  = $results->user_name;
				$user_email  = $results->user_email;
				$user_message  = $results->user_message;
				$product_name  = $results->product_name;
				$add_date  = $results->add_date;
	?>
			<tr>
				<td><?php echo $id; ?></td>
				<td><?php echo $user_name; ?></td>
                <td><?php echo $user_email; ?></td>
				<td><?php echo $user_message;?></td>
				<td><a href="<?php echo get_permalink($results->product_id); ?>" target="_blank"><?php echo $product_name;?></a></td>
				<td><?php echo $add_date; ?></td>
				<td><a href="#" id="<?php echo $results->id; ?>" class="del_inquire">Delete</a></td>
			</tr>
<?php }
	} else { ?>
			<tr align="center">
				<td colspan="6">No Record Found!</td>
			<tr>
	<?php } ?>
	</tbody>
	</table>
</div>


<script type="text/javascript">
jQuery(document).ready(function() {
jQuery(".del_inquire").click(function() {
			var del_id = jQuery(this).attr("id");
						
			var user_confirm = confirm("Are you sure to delete this record?");
			if (user_confirm == true) {
					jQuery.ajax({
					url: ajaxurl,
					data: {
						'action':'del_inquire_record',
						'del_id' : del_id
					},
					 success:function(data) {
						location.reload(true);					
				},
			error: function(errorThrown){
				console.log(errorThrown);
				alert("Error in delete");
			}
			});
			} 
		});
		});
</script>		
